import pyttsx3 #pip install pyttsx3
import speech_recognition as sr #pip install speechRecognition
import datetime
import wikipedia #pip install wikipedia
import webbrowser
import os
import smtplib
import tkinter as tk
class VT():
    def __init__(self):
        engine = pyttsx3.init('sapi5')
        voices = engine.getProperty('voices')
        # print(voices[1].id)
        engine.setProperty('voice', voices[0].id)


    def speak(self,audio):
        self.engine.say(audio)
        self.engine.runAndWait()


    def wishMe(self):
        hour = int(datetime.datetime.now().hour)
        if hour>=0 and hour<12:
            self.speak("Good Morning!")

        elif hour>=12 and hour<18:
            self.speak("Good Afternoon!")   

        else:
            self.speak("Good Evening!")  

        self.speak("I am Jarvis Sir. Please tell me how may I help you")       

    def takeCommand(self):
        #It takes microphone input from the user and returns string output

        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            r.pause_threshold = 1
            audio = r.listen(source)

        try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='en-in')
            print(f"User said: {query}\n")

        except Exception as e:
            # print(e)    
            print("Say that again please...")  
            return "None"
        return query

    def sendEmail(self,to, content):
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.ehlo()
        server.starttls()
        server.login('youremail@gmail.com', 'your-password')
        server.sendmail('youremail@gmail.com', to, content)
        server.close()
    class VoiceAssistantUI:
        def __init__(self):
            self.root = tk.Tk()
            self.root.title("Voice Assistant")

            self.label = tk.Label(self.root, text="Voice Assistant")
            self.label.pack(pady=10)

            self.text_display = tk.Text(self.root, height=10, width=50)
            self.text_display.pack(pady=10)

            self.button = tk.Button(self.root, text="Start Listening", command=self.start_listening)
            self.button.pack(pady=10)

            self.recognizer = sr.Recognizer()

        def start_listening(self):
            self.button["state"] = "disabled"
            self.text_display.delete(1.0, tk.END)
            with sr.Microphone() as source:
                self.text_display.insert(tk.END, "Listening...\n")
                self.recognizer.adjust_for_ambient_noise(source)
                audio = self.recognizer.listen(source, timeout=5)

            try:
                self.text_display.insert(tk.END, "Recognizing...\n")
                query = self.recognizer.recognize_google(audio)
                self.text_display.insert(tk.END, f"You said: {query}\n")
                # Add your logic for processing the query here

            except sr.UnknownValueError:
                self.text_display.insert(tk.END, "Sorry, I didn't catch that.\n")
            except sr.RequestError as e:
                self.text_display.insert(tk.END, f"Error with the speech recognition service; {e}\n")

            self.button["state"] = "normal"

        def run(self):
            self.root.mainloop()

  


if __name__ == "__main__":
    Vt=VT()
    voice_assistant_ui = VT.VoiceAssistantUI()
    voice_assistant_ui.run()
    Vt.wishMe()
    while True:
    # if 1:
        query = Vt.takeCommand().lower()

        # Logic for executing tasks based on query
        if 'wikipedia' in query:
            Vt.speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            Vt.speak("According to Wikipedia")
            print(results)
            Vt.speak(results)

        elif 'open youtube' in query:
            webbrowser.open("youtube.com")

        elif 'open google' in query:
            webbrowser.open("google.com")

        elif 'open stackoverflow' in query:
            webbrowser.open("stackoverflow.com")   


        elif 'play music' in query:
            music_dir = 'D:\\Non Critical\\songs\\Favorite Songs2'
            songs = os.listdir(music_dir)
            print(songs)    
            os.startfile(os.path.join(music_dir, songs[0]))

        elif 'the time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")    
            Vt.speak(f"Sir, the time is {strTime}")

        elif 'open code' in query:
            codePath = "C:\\Users\\Haris\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
            os.startfile(codePath)

        elif 'email to harry' in query:
            try:
                Vt.speak("What should I say?")
                content = Vt.takeCommand()
                to = "harryyourEmail@gmail.com"    
                Vt.sendEmail(to, content)
                Vt.speak("Email has been sent!")
            except Exception as e:
                print(e)
                Vt.speak("Sorry my friend harry bhai. I am not able to send this email")    
